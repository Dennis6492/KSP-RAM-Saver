Unzip "KSP RAM Saver.exe" on KSP root folder (were KSP.exe is)
Run "KSP RAM Saver.exe", a black window should appear, KSP should open in a few seconds, after that you can close the black window.
Enjoy your buffed up KSP!


Made for windows
This makes the KSP 32 bit version run better saving RAM
Tested on KSP 0.25, may as well work for older versions.
May not perform well on all systems.
Does not modify any file, it does not messes with anything, just tells KSP how to run better, as in "Hey KSP if you do this you can use less RAM and have the same quality and performance".